<?php
// register.php (alias for ragister.php for correct URL)
// Redirect to ragister.php for backward compatibility
header('Location: ragister.php');
exit();
