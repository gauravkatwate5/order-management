</div>
<footer class="footer mt-5 py-3 bg-white border-top shadow-sm">
	<div class="container text-center">
		<span class="text-muted">&copy; <?php echo date('Y'); ?> Order Management System</span>
	</div>
</footer>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>